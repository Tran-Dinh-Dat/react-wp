import './App.css';
import { Routes, Route } from 'react-router-dom';
import { publicRoutes } from './routers';
import MainLayout from 'layouts/MainLayout';
import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  // const [categoryName, setCategoryName] = useState([]);
  // const [errorMsg, setErrorMsg] = useState('');

 
  // useEffect(() => {
  //   const loadCategoryName = async () => {
  //     try {
  //       const response = await axios.get(
  //         `https://mothaibatest.000webhostapp.com/wp-json/wp/v2/categories?post=6`
  //       );
  //       setCategoryName([...categoryName, ...response.data]);
  //       setErrorMsg('');
  //     } catch (error) {
  //       setErrorMsg('Error while loading data. Try again later.');
  //     }
  //   };

  //   loadCategoryName();
  // }, []);

  // let cates = []
  // let a = categoryName.map(cate => {
  //   return cate.name
  // })
  // console.log("cates");
  // console.log(a);
  // console.log("cates");
  return (
    <Routes>
      <Route element={<MainLayout />}>
        {publicRoutes.map(({ path, component }, index) => (
          <Route path={path} element={component} key={index} />
        ))}
      </Route>
    </Routes>
  );
}

export default App;
