function Categories({category}) {
  console.log('cate  .  categories');
  console.log(category.name);
  console.log('cate  .  categories');
 
  return ( 
    <>
    {category.name}, 
    </>
   );
}

export default Categories;
