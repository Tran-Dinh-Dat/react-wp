function Banner() {
  return (
    <>
      <section className="p-top1 c-randompost l-container">
        <div className="c-randompost__inner">
          <a href="#" className="box-img">
            <img src="assets/img/img-1000x360.jpg" alt="#" />
            <div className="c-randompost__info">
              <div className="c-tag c-tag--pink">Category 1</div>
              <h3 className="c-randompost__title">
                Title title title<span>title</span>
                <span>title</span>
                <span>title</span>
                <span>title</span> title<span>title</span>
                <br /> title<span>title</span>
                <span>title</span>
                <span>title</span>
              </h3>
            </div>
          </a>
        </div>
      </section>
    </>
  );
}

export default Banner;
